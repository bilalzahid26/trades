package com.company;


import java.io.*;
import java.util.ArrayList;


public class Main {

    public static void main(String[] args) throws IOException {

        String tickerSymbol = "";
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        do {
            tickerSymbol = br.readLine();
        } while (tickerSymbol.length() != 4);

        ArrayList<Stock> listOfStock = new ArrayList<>();
        listOfStock.add(new Stock(tickerSymbol));
        if (listOfStock.size() != 0) {

            listOfStock.get(0).getHistoricStock(listOfStock.get(0).getExchange(), tickerSymbol);
        }
        System.out.println(listOfStock.get(0).getName());

    }
}
